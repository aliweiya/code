import glob
import os

import numpy as np

from skimage import io, transform
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder  
from sklearn.utils import shuffle

import tensorflow as tf

class AlexNet:
    """
    https://blog.csdn.net/qq_26499769/article/details/82928178
    """

    def __init__(self, height, width, channel, num_classes, dataset_path):
        self.keep_prob = 0.7
        self.filewriter_path = 'tensorboard'
        self.ckpt_path = 'ckpt/alexnet.ckpt'
        self.learning_rate = 1e-4
        self.epochs = 10
        self.dataset_path = dataset_path

        self.height = height
        self.width = width
        self.channel = channel
        self.num_classes = num_classes

        self.x = tf.placeholder(tf.float32, [None, height, width, channel], name='x')
        self.y_ = tf.placeholder(tf.int32, [None, num_classes], name='y')
        self.keep_prob_placeholder = tf.placeholder(tf.float32, name='keep_prob')

        g = tf.get_default_graph()
        self.sess = tf.Session(graph=g)

        self.build()

    def build(self):
        with tf.name_scope("conv1") as scope:
            """
            if (input_height % strides[1] == 0):
                pad_along_height = max(filter_height - strides[1], 0)
            else:
                pad_along_height = max(filter_height - (input_height % strides[1]), 0)

            if input_height = 227, pad_along_height = 8

            after convolution, the size is [?, (227 + 8 - 11) / 4 + 1, (227 + 8 - 11) / 4 + 1, 96],
            = [?, 57, 57, 96]
            """
            # [kernel_height, kernel_width, channel_in, channel_out]
            kernel = tf.Variable(tf.truncated_normal([11, 11, 3, 96],
                                                      mean=0,
                                                      stddev=0.1,
                                                      dtype=tf.float32), name="weights")
            # SAME: padding with inf, VALID: no padding
            # batch, height, width, channel
            conv = tf.nn.conv2d(self.x, kernel, [1, 4, 4, 1], padding="SAME")
            biases = tf.Variable(tf.constant(0.0, shape=[96], dtype=tf.float32),
                                 trainable=True, name='biases')
            bias = tf.nn.bias_add(conv, biases)
            conv1 = tf.nn.relu(bias, name=scope)

            # [?, 57, 57, 96]
            print(conv1.shape)

        with tf.name_scope('lrn1') as scope:
            """
            Hinton在2012年的Alexnet网络中提出

            在2015年 Very Deep Convolutional Networks for Large-Scale Image Recognition.提到LRN基本没什么用。
            """
            lrn1 = tf.nn.lrn(conv1, alpha=1e-4, beta=0.75,
                             depth_radius=2, bias=2.0)

        with tf.name_scope("pool1") as scope:
            """
            Input size: [?, 57, 57, 96]
            Output Size: [?, (57 - 3) / 2 + 1, (57 - 3) / 2 + 1, 96] = [?, 28, 28, 96]
            """
            pool1 = tf.nn.max_pool(lrn1,
                                   ksize=[1, 3, 3, 1],
                                   strides=[1, 2, 2, 1],
                                   padding='VALID')

        with tf.name_scope('conv2') as scope:
            """
            Input size: [?, 28, 28, 96]
            Output size: [?, (28 + 4 - 5) / 1 + 1, (28 + 4 - 5) / 1 + 1, 256] = [?, 28, 28, 256]
            """
            kernel = tf.Variable(tf.truncated_normal([5, 5, 96, 256],
                                                     dtype=tf.float32,
                                                     mean=0,
                                                     stddev=1e-1), name='weights')
            conv = tf.nn.conv2d(pool1, kernel, [1, 1, 1, 1], padding="SAME")
            biases = tf.Variable(tf.constant(0.0, shape=[256], dtype=tf.float32),
                                 trainable=True, name='biases')

            bias = tf.nn.bias_add(conv, biases)
            conv2 = tf.nn.relu(bias, name=scope)

        with tf.name_scope('lrn2') as scope:
            lrn2 = tf.nn.lrn(conv2,
                                                     alpha=1e-4,
                                                     beta=0.75,
                                                     depth_radius=2,
                                                     bias=2.0)

        with tf.name_scope('pool2') as scope:
            """
            Input size: [?, 28, 28, 256]
            Output size: [?, (28 - 3) / 2 + 1, (28 - 3) / 2 + 1, 256] = [?, 13, 13, 256]
            """
            pool2 = tf.nn.max_pool(lrn2, ksize=[1, 3, 3, 1],
                                   strides=[1, 2, 2, 1],
                                   padding="VALID")

        with tf.name_scope('conv3') as scope:
            """
            Input size: [?, 13, 13, 256]
            Outpuy size: [?, 13, 13, 384]
            """
            kernel = tf.Variable(tf.truncated_normal([3, 3, 256, 384],
                                                     dtype=tf.float32,
                                                     mean=0,
                                                     stddev=1e-1), name='weights')
            conv = tf.nn.conv2d(pool2, kernel, [1, 1, 1, 1], padding="SAME")
            biases = tf.Variable(tf.constant(0.0, shape=[384], dtype=tf.float32),
                                 trainable=True, name='biases')

            bias = tf.nn.bias_add(conv, biases)
            conv3 = tf.nn.relu(bias, name=scope)

        with tf.name_scope('conv4') as scope:
            """
            Input size: [?, 13, 13, 384]
            Output size: [?, 13, 13, 384]
            """
            kernel = tf.Variable(tf.truncated_normal([3, 3, 384, 384],
                                                     dtype=tf.float32,
                                                     mean=0,
                                                     stddev=1e-1), name='weights')
            conv = tf.nn.conv2d(conv3, kernel, [1, 1, 1, 1], padding="SAME")
            biases = tf.Variable(tf.constant(0.0, shape=[384], dtype=tf.float32),
                                 trainable=True, name='biases')

            bias = tf.nn.bias_add(conv, biases)
            conv4 = tf.nn.relu(bias, name=scope)

        with tf.name_scope('conv5') as scope:
            """
            Input size: [?, 13, 13, 384]
            Output size: [?, 13, 13, 256]
            """
            kernel = tf.Variable(tf.truncated_normal([3, 3, 384, 256],
                                                     dtype=tf.float32,
                                                     mean=0,
                                                     stddev=1e-1), name='weights')
            conv = tf.nn.conv2d(conv4, kernel, [1, 1, 1, 1], padding="SAME")
            biases = tf.Variable(tf.constant(0.0, shape=[256], dtype=tf.float32),
                                 trainable=True, name='biases')

            bias = tf.nn.bias_add(conv, biases)
            conv5 = tf.nn.relu(bias, name=scope)

        with tf.name_scope('pool5') as scope:
            """
            Input size: [?, 13, 13, 256]
            Output size: [?, 6, 6, 256]
            """
            pool5 = tf.nn.max_pool(conv5, ksize=[1, 3, 3, 1],
                                   strides=[1, 2, 2, 1],
                                   padding="VALID")

        with tf.name_scope('flattened') as scope:
            flattened = tf.reshape(pool5, shape=[-1, 6 * 6 * 256])

        with tf.name_scope("fc6") as scope:
            weights = tf.Variable(tf.truncated_normal([6 * 6 * 256, 4096],
                                                      dtype=tf.float32,
                                                      mean=0,
                                                      stddev=1e-1), name='weights')
            biases = tf.Variable(tf.constant(0.0, shape=[4096], dtype=tf.float32),
                                 trainable=True, name='biases')
            bias = tf.nn.xw_plus_b(flattened, weights, biases)
            fc6 = tf.nn.relu(bias)

        with tf.name_scope('dropout6') as scope:
            dropout6 = tf.nn.dropout(fc6, self.keep_prob_placeholder)

        with tf.name_scope('fc7') as scope:
            weights = tf.Variable(tf.truncated_normal([4096, 4096],
                                                      dtype=tf.float32,
                                                      stddev=1e-1), name='weights')

            biases = tf.Variable(tf.constant(0.0, shape=[4096], dtype=tf.float32),
                                 trainable=True, name='biases')
            bias = tf.nn.xw_plus_b(dropout6, weights, biases)
            fc7 = tf.nn.relu(bias)

        with tf.name_scope('dropout7') as scope:
            dropout7 = tf.nn.dropout(fc7, self.keep_prob_placeholder)

        with tf.name_scope('fc8') as scope:
            weights = tf.Variable(tf.truncated_normal([4096, self.num_classes],
                                                      dtype=tf.float32,
                                                      mean=0,
                                                      stddev=1e-1), name='weights')
            biases = tf.Variable(tf.constant(0.0, shape=[self.num_classes], dtype=tf.float32),
                                 trainable=True, name='biases')
            self.fc8 = tf.nn.xw_plus_b(dropout7, weights, biases)

    def get_batch(self, batch_size=32, train=True):
        if train:
            x, y = self.x_train, self.y_train
        else:
            x, y = self.x_test, y_test

        offset = 0
        while True:
            data_batch = x[offset:offset + batch_size]
            label_batch = y[offset:offset + batch_size]
            offset += batch_size

            image_batch = []
            for image in data_batch:
                _image = io.imread(image)
                _image = transform.resize(_image, (self.height, self.width, self.channel))
                image_batch.append(_image)

            yield np.array(image_batch), label_batch

    def load_dataset(self):
        datasets = glob.glob(os.path.join(self.dataset_path, '*.jpg'))
        datasets = shuffle(datasets)

        labels = [0 if sample.split(os.path.sep)[-1].split('.')[0] == 'dog' else 1 for sample in datasets]
        labels = np.array(labels).reshape(-1, 1)

        onehotEncoder = OneHotEncoder()
        onehotEncoder.fit([[0], [1]])
        labels = onehotEncoder.transform(labels).toarray()
        self.x_train, self.y_train, self.y_train, self.y_test = train_test_split(datasets, labels, test_size=0.3, random_state=0)

    def load(self):
        saver = tf.train.Saver()
        saver.restore(self.sess, self.ckpt_path)

    def train(self):
        if not hasattr(self, 'x_train'):
            self.load_dataset()

        with tf.name_scope('loss'):
            loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=self.fc8, labels=self.y_))

        with tf.name_scope('optimizer'):
            optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
            train_op = optimizer.minimize(loss)

        with tf.name_scope('accuracy'):
            correct_pred = tf.equal(tf.argmax(self.fc8, 1), tf.argmax(self.y_, 1))
            accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))

        tf.summary.scalar('loss', loss)
        tf.summary.scalar('accuracy', accuracy)
        merged_summary = tf.summary.merge_all()
        writer = tf.summary.FileWriter(self.filewriter_path)

        saver = tf.train.Saver()

        self.sess.run(tf.global_variables_initializer())

        total_batch = 0
        for epoch in range(self.epochs):
            for batch, (train_data_batch, train_label_batch) in enumerate(self.get_batch()):
                _, _loss, _acc = self.sess.run([train_op, loss, accuracy], feed_dict={self.x: train_data_batch, self.y_: train_label_batch, self.keep_prob_placeholder: self.keep_prob})
                print('Epoch: {}, batch: {}, loss: {}, acc: {}'.format(epoch, batch, _loss, _acc))

                result = self.sess.run(merged_summary, feed_dict={self.x: train_data_batch, self.y_: train_label_batch, self.keep_prob_placeholder: self.keep_prob})
                writer.add_summary(result, total_batch)

            test_data, test_label = self.get_batch(train=False)
            _loss, _acc = self.sess.run([loss, accuracy], feed_dict={self.x:test_data, self.y_: test_label, self.keep_prob_placeholder: 1})
            print('Test loss: {}, acc: {}'.format(_loss, _acc))
            saver.save(self.sess, self.ckpt_path, global_step=epoch)

    def predict(self, data):
        y = self.sess.run(self.outputs, feed_dict={self.x: data})
        return y